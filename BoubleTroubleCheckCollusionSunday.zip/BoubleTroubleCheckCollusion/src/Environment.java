

public class Environment {

    //constant
    protected final double GRAVITATION_CONSTANT = 0.06; //suggested: 3*9


    //variables
    public static double playerX;
    public static double playerY;
    public double playerWidth;
    public double playerHeight;

    public static double arrowX;
    public static double tipOfArrowY;
    public static boolean arrowExists=false;

    public double ballX;
    public double ballY;
    public double level;
    public double ballVelocityX;
    public double ballVelocityY;
    public double radius;
    public boolean ballExists=false;



    //



    public static void drawGameScreen(){
    //    StdDraw.picture(8.0,10.0/2.18,"gamescreen.png",16/3.8,10.0/4); //suggested

        //if()
    }

}
