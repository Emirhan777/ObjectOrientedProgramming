public class SquareMovingSquareTrial {

    



}
