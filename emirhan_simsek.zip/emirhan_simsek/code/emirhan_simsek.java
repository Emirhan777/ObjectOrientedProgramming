/*Emirhan Şimşek 2021402189 16.04.2023
This code is a game. Original game is called Bouble Trouble. We have a player that can shoot an arrow and
split bouncing balls into two. Game goes on until won or lost.
You win if you all the balls are popped,
You lose if a ball has hit the player or the time is up which is 40 seconds
*/

import java.awt.Font;
import java.awt.event.KeyEvent;


public class emirhan_simsek {
    public static void main(String[] args) {


        boolean gameContinues = true;

        while (gameContinues) { //runs as long as game continues
            boolean gameWon=false;
            boolean gameLost=false;


            //set canvas
            int canvasWidth = 800;
            int canvasHeight = 500;

            int green = 255;
            double timePast = 0;

            StdDraw.setCanvasSize(canvasWidth, canvasHeight); // set the size of the drawing canvas
            StdDraw.setXscale(0.0, 16.0); // set the scale of the coordinate system
            StdDraw.setYscale(-1.0, 9.0);
            StdDraw.enableDoubleBuffering();


            //construct all the objects

            Player player = new Player(8.0, (37.0/23.0)*(5.4/8.0)/2); //suggested: (37.0 / 27.0) * (10.0 / 8.0)
            Arrow arrow = new Arrow(8.0, player.playerHeight);

            //array of objects for balls
            Ball balls0;
            Ball[] balls1 = new Ball[3];
            Ball[] balls2 = new Ball[7];


            //construct all the possible balls
            balls0 = new Ball(16.0/4.0, 0.5, 0, true, (16.0/15.0)); //suggested: Level 0: (scaleX/4, 0.5) moving right
            for (int i = 0; i < balls1.length; i++) {
                if (i == 0) {
                    balls1[i] = new Ball(16.0/3.0, 0.5, 1, true, -(16.0/15.0)); //suggested: Level 1: (scaleX/3, 0.5) moving left
                } else {
                    balls1[i] = new Ball(16.0/3.0, 0.5, 0, false, -(16.0/15.0));
                }
            }
            for (int i = 0; i < balls2.length; i++) {
                if (i == 0) {
                    balls2[i] = new Ball(16.0/4.0, 0.5, 2, true, (16.0/15.0)); //suggested: Level 2: (scaleX/4, 0.5) moving right
                } else if (i == 1 || i == 2) {
                    balls2[i] = new Ball(16.0/4.0, 0.5, 1, false, (16.0/15.0));
                } else {
                    balls2[i] = new Ball(16.0/4.0, 0.5, 0, false, (16.0/15.0));
                }
            }


            Bar bar = new Bar(8, -0.5);


            int pauseDuration = 15;

            double startTime = System.currentTimeMillis() / 1000.0;

            while (timePast < 40.0 && !gameLost && !gameWon) { //total game duration is 40 secs, game runs until won or lost

                double timePast1 = timePast; //take time past before previous iteration
                timePast = System.currentTimeMillis() / 1000.0 - startTime; //refresh time past
                double iterationTimePast = timePast - timePast1;


                StdDraw.clear(); //clear previous drawing

                //move all the player, arrow, balls and bar
                player.move(iterationTimePast);
                arrow.move(iterationTimePast);

                //to print Y coordinate of the tip of arrow: System.out.println("tipOfArrow: " + arrow.tipOfArrowY);

                balls0.move(iterationTimePast);
                for (Ball ball : balls1) {
                    ball.move(iterationTimePast);
                }
                for (Ball ball : balls2) {
                    ball.move(iterationTimePast);
                }
                bar.move(iterationTimePast);



                //checking balls one by one if they collide with player then checking if they collide with arrow
                if (balls0.ballExists &&
                        ((balls0.ballX < player.playerX + player.playerWidth / 2 - 0.0 + balls0.radius && balls0.ballX > player.playerX - player.playerWidth / 2 + 0.0 - balls0.radius && balls0.ballY < player.playerHeight - 0.0) ||
                                (balls0.ballX < player.playerX + player.playerWidth / 2 - 0.0 && balls0.ballX > player.playerX - player.playerWidth / 2 + 0.0 && balls0.ballY < player.playerHeight - 0.0 + balls0.radius) ||
                                ((balls0.ballX - player.playerX - player.playerWidth / 2 + 0.0) * (balls0.ballX - player.playerX - player.playerWidth / 2 + 0.0) + (balls0.ballY - player.playerHeight + 0.0) * (balls0.ballY - player.playerHeight + 0.0) < balls0.radius * balls0.radius) ||
                                ((balls0.ballX - player.playerX + player.playerWidth / 2 - 0.0) * (balls0.ballX - player.playerX + player.playerWidth / 2 - 0.0) + (balls0.ballY - player.playerHeight + 0.0) * (balls0.ballY - player.playerHeight + 0.0) < balls0.radius * balls0.radius))) {
                    gameLost = true;
                } else if (arrow.arrowExists && balls0.ballExists &&
                        (((balls0.ballX - balls0.radius) < arrow.arrowX && (balls0.ballX + balls0.radius) > arrow.arrowX && balls0.ballY < arrow.tipOfArrowY) ||
                                ((balls0.ballX - arrow.arrowX) * (balls0.ballX - arrow.arrowX) + (balls0.ballY - arrow.tipOfArrowY) * (balls0.ballY - arrow.tipOfArrowY) < balls0.radius * balls0.radius))) {
                    arrow.arrowExists = false;
                    balls0.ballExists = false;
                    //System.out.println("hit");
                }

                for (int i = 0; i < balls1.length; i++) {
                    if (balls1[i].ballExists &&
                            ((balls1[i].ballX < player.playerX + player.playerWidth / 2 - 0.0 + balls1[i].radius && balls1[i].ballX > player.playerX - player.playerWidth / 2 + 0.0 - balls1[i].radius && balls1[i].ballY < player.playerHeight - 0.0) ||
                                    (balls1[i].ballX < player.playerX + player.playerWidth / 2 - 0.0 && balls1[i].ballX > player.playerX - player.playerWidth / 2 + 0.0 && balls1[i].ballY < player.playerHeight - 0.0 + balls1[i].radius) ||
                                    ((balls1[i].ballX - player.playerX - player.playerWidth / 2 + 0.0) * (balls1[i].ballX - player.playerX - player.playerWidth / 2 + 0.0) + (balls1[i].ballY - player.playerHeight + 0.0) * (balls1[i].ballY - player.playerHeight + 0.0) < balls1[i].radius * balls1[i].radius) ||
                                    ((balls1[i].ballX - player.playerX + player.playerWidth / 2 - 0.0) * (balls1[i].ballX - player.playerX + player.playerWidth / 2 - 0.0) + (balls1[i].ballY - player.playerHeight + 0.0) * (balls1[i].ballY - player.playerHeight + 0.0) < balls1[i].radius * balls1[i].radius))) {
                        gameLost = true;
                        } else if (arrow.arrowExists && balls1[i].ballExists &&
                            (((balls1[i].ballX - balls1[i].radius) < arrow.arrowX && (balls1[i].ballX + balls1[i].radius) > arrow.arrowX && balls1[i].ballY < arrow.tipOfArrowY) ||
                                    ((balls1[i].ballX - arrow.arrowX) * (balls1[i].ballX - arrow.arrowX) + (balls1[i].ballY - arrow.tipOfArrowY) * (balls1[i].ballY - arrow.tipOfArrowY) < balls1[i].radius * balls1[i].radius))) {
                        arrow.arrowExists = false;
                        balls1[i].ballExists = false;
                        //System.out.println("hit");
                        if (i == 0) {//the refreshed velocity of new balls are dependent on the level
                            balls1[1].ballExists = true;
                            balls1[1].ballVelocityY = Math.sqrt(2*10*0.0175*20*Math.pow(1.75,balls1[1].level));
                            balls1[1].ballX = balls1[0].ballX;
                            balls1[1].ballY = balls1[0].ballY;
                            
                            balls1[2].ballExists = true;
                            balls1[2].ballVelocityY = Math.sqrt(2*10*0.0175*20*Math.pow(1.75,balls1[2].level));
                            balls1[2].ballVelocityX = -balls1[2].ballVelocityX;
                            balls1[2].ballX = balls1[0].ballX;
                            balls1[2].ballY = balls1[0].ballY;
                        }
                    }
                }

                for (int i = 0; i < balls2.length; i++) {
                    if (balls2[i].ballExists &&
                            ((balls2[i].ballX < player.playerX + player.playerWidth / 2 - 0.0 + balls2[i].radius && balls2[i].ballX > player.playerX - player.playerWidth / 2 + 0.0 - balls2[i].radius && balls2[i].ballY < player.playerHeight - 0.0) ||
                                    (balls2[i].ballX < player.playerX + player.playerWidth / 2 - 0.0 && balls2[i].ballX > player.playerX - player.playerWidth / 2 + 0.0 && balls2[i].ballY < player.playerHeight - 0.0 + balls2[i].radius) ||
                                    ((balls2[i].ballX - player.playerX - player.playerWidth / 2 + 0.0) * (balls2[i].ballX - player.playerX - player.playerWidth / 2 + 0.0) + (balls2[i].ballY - player.playerHeight + 0.0) * (balls2[i].ballY - player.playerHeight + 0.0) < balls2[i].radius * balls2[i].radius) ||
                                    ((balls2[i].ballX - player.playerX + player.playerWidth / 2 - 0.0) * (balls2[i].ballX - player.playerX + player.playerWidth / 2 - 0.0) + (balls2[i].ballY - player.playerHeight + 0.0) * (balls2[i].ballY - player.playerHeight + 0.0) < balls2[i].radius * balls2[i].radius))) {
                        gameLost = true;
                    } else if (arrow.arrowExists && balls2[i].ballExists &&
                            (((balls2[i].ballX - balls2[i].radius) < arrow.arrowX && (balls2[i].ballX + balls2[i].radius) > arrow.arrowX && balls2[i].ballY < arrow.tipOfArrowY) ||
                                    ((balls2[i].ballX - arrow.arrowX) * (balls2[i].ballX - arrow.arrowX) + (balls2[i].ballY - arrow.tipOfArrowY) * (balls2[i].ballY - arrow.tipOfArrowY) < balls2[i].radius * balls2[i].radius))) {
                        arrow.arrowExists = false;
                        balls2[i].ballExists = false;
                        //System.out.println("hit");
                        if (i == 0) { //the refreshed velocity of new balls are dependent on the level
                            balls2[1].ballExists = true;
                            balls2[1].ballVelocityY = Math.sqrt(2*10*0.0175*20*Math.pow(1.75,balls2[1].level));//Math.sqrt(2*10*0.0175*20*Math.pow(1.75,balls2[1].level))
                            balls2[1].ballX = balls2[0].ballX;
                            balls2[1].ballY = balls2[0].ballY;

                            balls2[2].ballExists = true;
                            balls2[2].ballVelocityY = Math.sqrt(2*10*0.0175*20*Math.pow(1.75,balls2[2].level));//Math.sqrt(2*10*0.0175*20*Math.pow(1.75,balls2[1].level))
                            balls2[2].ballVelocityX = -balls2[2].ballVelocityX;
                            balls2[2].ballX = balls2[0].ballX;
                            balls2[2].ballY = balls2[0].ballY;
                        } else if (i == 1 || i == 2) { //the balls from index 3 to 7 are the level 0 balls split from the biggest initial ball after 2 splits
                            balls2[i + 2].ballExists = true;
                            balls2[i + 2].ballVelocityY = 3.5;//Math.sqrt(2*10*0.0175*20*Math.pow(1.75,balls2[i + 4].level))
                            balls2[i + 2].ballX = balls2[i].ballX;
                            balls2[i + 2].ballY = balls2[i].ballY;

                            balls2[i + 4].ballExists = true;
                            balls2[i + 4].ballVelocityY = 3.5;//Math.sqrt(2*10*0.0175*20*Math.pow(1.75,balls2[i + 4].level))
                            balls2[i + 4].ballVelocityX = -balls2[i + 4].ballVelocityX;
                            balls2[i + 4].ballX = balls2[i].ballX;
                            balls2[i + 4].ballY = balls2[i].ballY;
                        }
                    }
                }

                //draw all the pictures on canvas

                StdDraw.picture(8, 4, "background.png", 16, 10);

                if (arrow.tipOfArrowY < 9 && arrow.arrowExists) {
                    StdDraw.picture(arrow.arrowX, arrow.tipOfArrowY / 2, "arrow.png", 0.1, arrow.tipOfArrowY);
                } else {
                    arrow.arrowExists = false;
                }

                StdDraw.picture(8, -0.5, "bar.png", 16, 1);
                StdDraw.picture(player.playerX, player.playerY, "player_back.png", player.playerWidth, player.playerHeight);

                //draw all the balls on canvas
                if (balls0.ballExists) {
                    StdDraw.picture(balls0.ballX, balls0.ballY, "ball.png", 2 * balls0.radius, 2 * balls0.radius);
                }
                for (int i = 0; i < balls1.length; i++) {
                    if (balls1[i].ballExists) {
                        StdDraw.picture(balls1[i].ballX, balls1[i].ballY, "ball.png", 2 * balls1[i].radius, 2 * balls1[i].radius);
                    }
                }
                for (int i = 0; i < balls2.length; i++) {
                    if (balls2[i].ballExists) {
                        StdDraw.picture(balls2[i].ballX, balls2[i].ballY, "ball.png", 2 * balls2[i].radius, 2 * balls2[i].radius);
                    }
                }

                //time bar loses the green value in RGB system and turns yellow to red
                int green2 = green - (int) ((timePast * 255) / 40);
                StdDraw.setPenColor(255, green2, 0);
                StdDraw.filledRectangle(bar.barX, bar.barY, 8, 0.25);

                //checking if the game is lost due to no time remaining
                if (timePast >= 40) {
                    gameLost = true;
                }
                if (gameLost) { //game screen
                    StdDraw.picture(8.0, 10.0 / 2.18, "game_screen.png", 16 / 3.8, 10.0 / 4); //suggested
                    StdDraw.setPenColor(StdDraw.BLACK);

                    StdDraw.setFont(new Font("Helvetica", Font.BOLD, 28));
                    StdDraw.text(8.0, 5.0, "Game Over!");

                    StdDraw.setFont(new Font("Helvetica", Font.ITALIC, 15));
                    StdDraw.text(8.0, 10 / 2.3, "To Replay Click “Y”");

                    StdDraw.setFont(new Font("Helvetica", Font.ITALIC, 15));
                    StdDraw.text(8.0, 10 / 2.6, "To Quit Click “N”");

                }

                //checking if the game is won thanks to success of player to pop all the balls
                gameWon=true;
                if(balls0.ballExists){gameWon=false;}
                for (Ball ball : balls1) {if(ball.ballExists){gameWon=false;}}
                for (Ball ball : balls2) {if(ball.ballExists){gameWon=false;}}

                if (gameWon) { //game screen
                    StdDraw.picture(8.0, 10.0 / 2.18, "game_screen.png", 16 / 3.8, 10.0 / 4); //suggested
                    StdDraw.setPenColor(StdDraw.BLACK);

                    StdDraw.setFont(new Font("Helvetica", Font.BOLD, 28));
                    StdDraw.text(8.0, 5.0, "You Won!");

                    StdDraw.setFont(new Font("Helvetica", Font.ITALIC, 15));
                    StdDraw.text(8.0, 10 / 2.3, "To Replay Click “Y”");

                    StdDraw.setFont(new Font("Helvetica", Font.ITALIC, 15));
                    StdDraw.text(8.0, 10 / 2.6, "To Quit Click “N”");

                }

                StdDraw.pause(pauseDuration);
                StdDraw.show();
                //to check total time past: System.out.println(timePast);
            }

            while (!(StdDraw.isKeyPressed(KeyEvent.VK_Y) || StdDraw.isKeyPressed(KeyEvent.VK_N))) { // waiting until user press Y or N
                //print while waiting: System.out.println("Waiting");
                StdDraw.pause(500); // pause for 500ms, thanks to this pressing for a short time does not activate, user need to hold buttons
            }

            if (StdDraw.isKeyPressed(KeyEvent.VK_Y)) // Y is pressed
                gameContinues = true; // play the game again

            if (StdDraw.isKeyPressed(KeyEvent.VK_N)){ // N is pressed
                gameContinues = false; // close the game
                System.exit(0);}
        }

    }
}